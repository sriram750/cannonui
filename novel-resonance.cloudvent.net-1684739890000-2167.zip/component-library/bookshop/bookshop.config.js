module.exports = {
	engines: {
		"@bookshop/jekyll-engine": {}
	}
}