---
_id: 05589684-8d33-4d2f-8fde-460f9922d319
name: Betty Jefferson
position: Developer
image: https://source.unsplash.com/collection/139386/602x602?a=.png
twitter: cloudcannon
blurb: Betty is a bookworm who will typically have four books on the go.
phone:
phone_extension:
---
