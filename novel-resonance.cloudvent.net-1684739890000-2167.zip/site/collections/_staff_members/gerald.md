---
_id: 1d47e0f6-d5b8-441b-a51c-16b6d3d1b409
name: Gerald Freeman
position: Sales
image: https://source.unsplash.com/collection/139386/603x603?a=.png
twitter: cloudcannon
blurb: Gerald loves going to bike rides and spending time with his family.
phone:
phone_extension:
---
