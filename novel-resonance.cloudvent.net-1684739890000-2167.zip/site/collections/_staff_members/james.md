---
_id: 45b8f5b9-ee07-4dd1-ba0c-d27c7e9c1f86
name: James Lopez
position: Developer
image: https://source.unsplash.com/collection/139386/604x604?a=.png
twitter: cloudcannon
blurb: James spends his weekends watching his favourite NBA team - L.A. Clippers.
phone:
phone_extension:
---
